--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: aasrepo; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA aasrepo;


ALTER SCHEMA aasrepo OWNER TO postgres;

--
-- Name: fn_instance_merge(bigint); Type: FUNCTION; Schema: aasrepo; Owner: postgres
--

CREATE FUNCTION aasrepo.fn_instance_merge(instance_id bigint) RETURNS jsonb
    LANGUAGE plpgsql
    AS $$
DECLARE
    rtn_json jsonb;
    submodel_json jsonb;
    submodel_record RECORD;
    submodel_id text;
    aas_array jsonb;
    aas jsonb;
BEGIN
    ----------------------------------------------
    -- instance_id에 해당하는 AAS metadata 조회
    ----------------------------------------------
    -- instance metadata
    SELECT metadata 
    INTO rtn_json
    FROM aasrepo.aasinstance_aasmodels
    WHERE instance_seq = instance_id;
	
    -- metadata 없으면 예외처리
    IF rtn_json IS NULL THEN
    	RETURN NULL;
--        RAISE EXCEPTION 'metadata not found instance_seq %', instance_id;
    END IF;

    ----------------------------------------------
    -- AAS 전체에서 'submodels' 배열이 없으면 빈 배열로 초기화
    ----------------------------------------------
    -- submodels 초기화
    IF jsonb_typeof(rtn_json->'submodels') IS DISTINCT FROM 'array' THEN
        rtn_json := jsonb_set(rtn_json, '{submodels}', '[]'::jsonb);
    END IF;

    ----------------------------------------------
    -- AAS 내부에 assetAdministrationShells 있는지 확인
    ----------------------------------------------
    -- assetAdministrationShells 확인 후 없으면 예외처리
    IF jsonb_typeof(rtn_json->'assetAdministrationShells') IS DISTINCT FROM 'array' THEN
    	RETURN NULL;
--        RAISE EXCEPTION 'assetAdministrationShells not found';
    END IF;

    aas_array := rtn_json->'assetAdministrationShells';
    aas := aas_array->0; -- 배열 첫번째만 사용함 (하나만 있다고 가정)

    ----------------------------------------------
    -- AAS 내부 submodels 없으면 초기화
    ----------------------------------------------
    IF jsonb_typeof(aas->'submodels') IS DISTINCT FROM 'array' THEN
        aas := jsonb_set(aas, '{submodels}', '[]'::jsonb);
    END IF;

    ----------------------------------------------
    -- instance의 모든 submodel들을 merge
    ----------------------------------------------
    FOR submodel_record IN
        SELECT metadata
        FROM aasrepo.aasinstance_aasmodel_submodels
        WHERE instance_seq = instance_id
    LOOP
        submodel_json := submodel_record.metadata; 
        submodel_id := submodel_json->>'id'; -- submodel id 추출 (id를 string으로)
        
    ----------------------------------------------
        -- AAS 전체 submodels 배열에 추가(중복체크)
    ----------------------------------------------
        IF NOT EXISTS (
            SELECT 1 
            FROM jsonb_array_elements(rtn_json->'submodels') AS sm
            WHERE sm->>'id' = submodel_id
        ) THEN
            rtn_json := jsonb_set(
                rtn_json,
                '{submodels}',
                (rtn_json->'submodels') || submodel_json
            );
        END IF;

        -- 참조에 submodel 추가
        IF NOT EXISTS (
            SELECT 1 
            FROM jsonb_array_elements(aas->'submodels') AS ref
            WHERE ref->'keys'->0->>'value' = submodel_id
        ) THEN
            aas := jsonb_set(
                aas,
                '{submodels}',
                (aas->'submodels') || jsonb_build_object(
                    'type', 'ModelReference',
                    'keys', jsonb_build_array(
                        jsonb_build_object(
                            'type', 'Submodel',
                            'value', submodel_id
                        )
                    )
                )
            );
        END IF;
    END LOOP;

    -- 최종 리턴값
    rtn_json := jsonb_set(
        rtn_json,
        '{assetAdministrationShells}',
        jsonb_build_array(aas)
    );

    RETURN rtn_json;
END;
$$;


ALTER FUNCTION aasrepo.fn_instance_merge(instance_id bigint) OWNER TO postgres;

--
-- Name: fncodelist(character varying, integer, character varying, character varying, character varying); Type: FUNCTION; Schema: aasrepo; Owner: postgres
--

CREATE FUNCTION aasrepo.fncodelist(grp_cd character varying, lang_index integer DEFAULT 1, ref_code1 character varying DEFAULT ''::character varying, ref_code2 character varying DEFAULT ''::character varying, ref_code3 character varying DEFAULT ''::character varying) RETURNS json
    LANGUAGE plpgsql
    AS $$
DECLARE
    
    result JSON;
begin 

	if grp_cd = 'category2' then
		select json_agg(row_to_json(r)) as result
			into result
		from (

					
				WITH RECURSIVE base_tbl as (
				
					select coalesce(refcode3, coalesce(refcode2, refcode1) ) as refcode1 , category_seq::varchar as code
						, CASE 1 
						WHEN 1  THEN a.category_name
					    WHEN 2  THEN a.category_name2
					    WHEN 3  THEN a.category_name3
					    WHEN 4  THEN a.category_name4
					    WHEN 5  THEN a.category_name5
					    ELSE a.category_name   end as title
					from aasrepo.categories a
					where status = 'Y'
					union all 
					select refcode1, code
						, CASE 1
				        WHEN 1  THEN a.codename
				        WHEN 2  THEN a.codename2
				        WHEN 3  THEN a.codename3
				        WHEN 4  THEN a.codename4
				        WHEN 5  THEN a.codename5
				        ELSE a.codename  end as title
					from aasrepo.aas_codeinfo a
					where  grpcode in ('GRP200', 'GRP300')
						and a.status ='Y'
				), cte_category_tbl as (
				
					select 0 as lv,  null::varchar as p_id , code::varchar as c_id
						, CASE 1
						        WHEN 1  THEN a.codename
						        WHEN 2  THEN a.codename2
						        WHEN 3  THEN a.codename3
						        WHEN 4  THEN a.codename4
						        WHEN 5  THEN a.codename5
						        ELSE a.codename  end::varchar as title
						 , row_number() over ( order by code) as seq
						 , LPAD(0::varchar, 3, '0') || LPAD(code::varchar, 10, '0') node_id
					from aasrepo.aas_codeinfo a
					where  grpcode = 'GRP200'
						
					union all
					
					select b.lv + 1 as lv,  b.c_id as p_id , a.code as c_id
						, a.title
				        , row_number() over (partition by b.c_id order by code) as seq
				        , b.node_id || LPAD((b.lv+1)::varchar, 3, '0') || LPAD(a.code::varchar, 10, '0') node_id
					from base_tbl a
					join cte_category_tbl b on b.c_id = a.refcode1
				) 
				select lv, p_id, c_id, seq, title, node_id
				from cte_category_tbl
				order by node_id
 
		) r;
	else 	
		
		select json_agg(row_to_json(r)) as result
			into result
		from (
			select "id", "text", "refcode1", "refcode2", "refcode3"
			from (
					SELECT code::varchar  AS "id",
			            CASE lang_index
			                WHEN 1  THEN codeName
			                WHEN 2  THEN codeName2
			                WHEN 3  THEN codeName3
			                WHEN 4  THEN codeName4
			                WHEN 5  THEN codeName5
			                ELSE codeName 
			            END::varchar AS text
						, refcode1 
						, refcode2
						, refcode3
						, coalesce(sortkey::varchar, code::varchar)::varchar as sortkey
			        FROM aasrepo.aas_codeinfo c
					where grpcode is not null
						and grpcode = fncodelist.grp_cd

         			union all 

			        -- 카테고리
			        SELECT a.category_seq::varchar AS id,
			            CASE lang_index
			                WHEN 1  THEN a.category_name
			                WHEN 2  THEN a.category_name2
			                WHEN 3  THEN a.category_name3
			                WHEN 4  THEN a.category_name4
			                WHEN 5  THEN a.category_name5
			                ELSE a.category_name 
			            END::varchar AS text
						, refcode1 
						, refcode2
						, refcode3
						, a.category_seq::varchar as sortkey
			        FROM aasrepo.categories a
					where fncodelist.grp_cd = 'category'
			
			        
			        UNION ALL
			        
			        -- 그룹
			        SELECT a.group_seq::varchar AS id,
			            CASE lang_index
			                WHEN 1  THEN a.group_name
			                WHEN 2  THEN a.group_name2
			                WHEN 3  THEN a.group_name3
			                WHEN 4  THEN a.group_name4
			                WHEN 5  THEN a.group_name5
			                ELSE a.group_name 
			            END::varchar AS text
						, '' as refcode1 
						, '' as refcode2
						, '' as refcode3
						, a.group_seq::varchar as sortkey
			        FROM aasrepo.groups a
					where fncodelist.grp_cd = 'group'
			
			        
			        UNION ALL
			        
			        -- 소셜
			        SELECT a.socialprovider_seq::varchar AS id,
			            a.socialprovider_name::varchar  AS text
						, '' as refcode1 
						, '' as refcode2
						, '' as refcode3
						, a.socialprovider_seq::varchar as sortkey
			        FROM aasrepo.socialproviders a
					where fncodelist.grp_cd = 'social'

			) 
			order by sortkey
			
			) r;
			
			


	end if;
	

	
    
    RETURN result;
END;
$$;


ALTER FUNCTION aasrepo.fncodelist(grp_cd character varying, lang_index integer, ref_code1 character varying, ref_code2 character varying, ref_code3 character varying) OWNER TO postgres;

--
-- Name: FUNCTION fncodelist(grp_cd character varying, lang_index integer, ref_code1 character varying, ref_code2 character varying, ref_code3 character varying); Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON FUNCTION aasrepo.fncodelist(grp_cd character varying, lang_index integer, ref_code1 character varying, ref_code2 character varying, ref_code3 character varying) IS '코드리스트';


--
-- Name: fncodenm(character varying, integer, character varying); Type: FUNCTION; Schema: aasrepo; Owner: postgres
--

CREATE FUNCTION aasrepo.fncodenm(p_code character varying, lang_index integer DEFAULT 1, grp_cd character varying DEFAULT ''::character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
    declare oCodeName varchar := '';

BEGIN


	select code_name into oCodeName
	from (
		select
			CASE fncodenm.lang_index
				WHEN 1  THEN codeName
				WHEN 2  THEN codeName2
				WHEN 3  THEN codeName3
				WHEN 4  THEN codeName4
				WHEN 5  THEN codeName5
				ELSE codeName END  as code_name
		from aasrepo.aas_codeinfo c
		where ( fncodenm.grp_cd = '' or fncodenm.grp_cd = 'code')
			and  code = p_code
		union all
		--카테고리
		select CASE fncodenm.lang_index
				WHEN 1  THEN a.category_name
				WHEN 2  THEN a.category_name2
				WHEN 3  THEN a.category_name3
				WHEN 4  THEN a.category_name4
				WHEN 5  THEN a.category_name5
				ELSE a.category_name END as code_name
		from aasrepo.categories a
		where ( fncodenm.grp_cd = '' or fncodenm.grp_cd = 'category')
			and  a.category_seq::varchar = p_code
		union all
		--Group
		select CASE fncodenm.lang_index
				WHEN 1  THEN a.group_name
				WHEN 2  THEN a.group_name2
				WHEN 3  THEN a.group_name3
				WHEN 4  THEN a.group_name4
				WHEN 5  THEN a.group_name5
				ELSE a.group_name END as code_name
		from aasrepo.groups a
		where ( fncodenm.grp_cd = '' or fncodenm.grp_cd = 'group')
			and  a.group_seq::varchar = p_code
		union all
		--social
		select a.socialprovider_name as code_name
		from aasrepo.socialproviders a
		where ( fncodenm.grp_cd = '' or fncodenm.grp_cd = 'social')
		and  a.socialprovider_seq::varchar = p_code

	) r
	limit 1;

    return oCodeName;

END;
$$;


ALTER FUNCTION aasrepo.fncodenm(p_code character varying, lang_index integer, grp_cd character varying) OWNER TO postgres;

--
-- Name: generator_code(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: aasrepo; Owner: postgres
--

CREATE FUNCTION aasrepo.generator_code(type character varying, ty_value character varying DEFAULT ''::character varying, ty_value2 character varying DEFAULT ''::character varying, ty_value3 character varying DEFAULT ''::character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_code VARCHAR(30);
    code_prefix VARCHAR(20);
BEGIN
    new_code := '';

    -- type 값에 따라 조건 설정
    IF type = 'aasmodel' THEN 
        -- ty_value 값이 비어있지 않은지 확인
        IF length(ty_value) > 0 THEN

            with header_info_tbl as (

				select a.category_seq
					, concat('AAS-', b.refcode2, '-', coalesce(c.refcode2, 'B'), '-' ) as prefix_header
				from aasrepo.categories a
				left join aasrepo.aas_codeinfo b on a.refcode1 = b.code and b.grpcode = 'GRP100'
				left join aasrepo.aas_codeinfo c on a.refcode2 = c.code and c.grpcode = 'GRP200'
				where a.status = 'Y'
					and ty_value3 = ''
					and a.category_seq::varchar = ty_value
				
			), max_model as (
			
				select left(aasmodel_template_id,8) as prefix_header, max(right(left(aasmodel_template_id,14),6)::int) max_seq
				from aasrepo.aasmodels a
				join header_info_tbl b on left(a.aasmodel_template_id,8) = b.prefix_header
				where aasmodel_template_id is not null
					and ty_value3 = ''
				group by left(aasmodel_template_id,8)
				
			), new_seq_tbl as (
				select a.category_seq, a.prefix_header, lpad( (coalesce(b.max_seq,0) + 1)::varchar,6,'0') as next_seq
				from header_info_tbl a
				left join max_model b on a.prefix_header = b.prefix_header
				where ty_value3 = ''

				union all
				
				select a.category_seq,  left(aasmodel_template_id, 8) as prefix_header , substring(aasmodel_template_id, 9,6) as next_seq
				from aasrepo.aasmodels a
				where coalesce(aasmodel_template_id , '') <> ''
					and ty_value3 <> ''
					and left(aasmodel_template_id, 14) = left(ty_value3, 14)
				
			)
			select concat(prefix_header, lpad(next_seq::text, 6, '0') , '-', replace( case when ty_value2 = '' then '0.1' else ty_value2 end , '.', '-' )) 
			into new_code
			from new_seq_tbl
			limit 1;
		ELSE
            RAISE EXCEPTION 'Invalid value ty_value: %', ty_value;
        END IF;


    ELSIF type = 'submodel' THEN 
		-- ty_value 값이 비어있지 않은지 확인
        IF length(ty_value) > 0 THEN

            with header_info_tbl as (

				select a.category_seq
					, concat('SUB-', b.refcode2, '-', coalesce(c.refcode2, 'B'), '-' ) as prefix_header
				from aasrepo.categories a
				left join aasrepo.aas_codeinfo b on a.refcode1 = b.code and b.grpcode = 'GRP100'
				left join aasrepo.aas_codeinfo c on a.refcode2 = c.code and c.grpcode = 'GRP200'
				where a.status = 'Y'
					and ty_value3 = ''
					and a.category_seq::varchar = ty_value
				
			), max_model as (
			
				select left(submodel_template_id,8) as prefix_header, max(right(left(submodel_template_id,14),6)::int) max_seq
				from aasrepo.submodels a
				join header_info_tbl b on left(a.submodel_template_id,8) = b.prefix_header
				where submodel_template_id is not null
					and ty_value3 = ''
				group by left(submodel_template_id,8)
				
			), new_seq_tbl as (
				select a.category_seq, a.prefix_header, lpad( (coalesce(b.max_seq,0) + 1)::varchar,6,'0') as next_seq
				from header_info_tbl a
				left join max_model b on a.prefix_header = b.prefix_header
				where ty_value3 = ''

				union all
				
				select a.category_seq,  left(submodel_template_id, 8) as prefix_header , substring(submodel_template_id, 9,6) as next_seq
				from aasrepo.submodels a
				where coalesce(submodel_template_id , '') <> ''
					and ty_value3 <> ''
					and left(submodel_template_id, 14) = left(ty_value3, 14)
				
			)
			
			select concat(prefix_header, lpad(next_seq::text, 6, '0') , '-', replace( case when ty_value2 = '' then '0.1' else ty_value2 end , '.', '-' )) 
			into new_code
			from new_seq_tbl
			limit 1;
	

		ELSE
            RAISE EXCEPTION 'Invalid ty_value: %', ty_value;
        END IF;
   
    ELSE
        RAISE EXCEPTION 'Invalid type value: %', type;
    END IF;

    RETURN new_code;
END;
$$;


ALTER FUNCTION aasrepo.generator_code(type character varying, ty_value character varying, ty_value2 character varying, ty_value3 character varying) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aas_codeinfo; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.aas_codeinfo (
    grpcode character varying(10),
    code character varying(20) NOT NULL,
    codename text,
    codename2 text,
    codename3 text,
    codename4 text,
    codename5 text,
    refcode1 character varying(400),
    refcode2 character varying(400),
    refcode3 character varying(400),
    refcode4 character varying(400),
    refcode5 character varying(400),
    sortkey integer,
    description text,
    status character(1) DEFAULT 'Y'::bpchar,
    create_user_seq integer,
    create_date timestamp with time zone,
    last_mod_user_seq integer,
    last_mod_date timestamp with time zone
);


ALTER TABLE aasrepo.aas_codeinfo OWNER TO postgres;

--
-- Name: TABLE aas_codeinfo; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.aas_codeinfo IS 'AAS코드관리';


--
-- Name: COLUMN aas_codeinfo.grpcode; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.grpcode IS '그룹코드';


--
-- Name: COLUMN aas_codeinfo.code; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.code IS '코드';


--
-- Name: COLUMN aas_codeinfo.codename; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.codename IS '코드명1';


--
-- Name: COLUMN aas_codeinfo.codename2; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.codename2 IS '코드명2';


--
-- Name: COLUMN aas_codeinfo.codename3; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.codename3 IS '코드명3';


--
-- Name: COLUMN aas_codeinfo.codename4; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.codename4 IS '코드명4';


--
-- Name: COLUMN aas_codeinfo.codename5; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.codename5 IS '코드명5';


--
-- Name: COLUMN aas_codeinfo.refcode1; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.refcode1 IS '참조코드1';


--
-- Name: COLUMN aas_codeinfo.refcode2; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.refcode2 IS '참조코드2';


--
-- Name: COLUMN aas_codeinfo.refcode3; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.refcode3 IS '참조코드3';


--
-- Name: COLUMN aas_codeinfo.refcode4; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.refcode4 IS '참조코드4';


--
-- Name: COLUMN aas_codeinfo.refcode5; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.refcode5 IS '참조코드5';


--
-- Name: COLUMN aas_codeinfo.sortkey; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.sortkey IS '정렬키';


--
-- Name: COLUMN aas_codeinfo.description; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.description IS '비고';


--
-- Name: COLUMN aas_codeinfo.status; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.status IS 'Y=활성,N=비활성';


--
-- Name: COLUMN aas_codeinfo.create_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.create_user_seq IS '최초생성자';


--
-- Name: COLUMN aas_codeinfo.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.create_date IS '최초생성일';


--
-- Name: COLUMN aas_codeinfo.last_mod_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.last_mod_user_seq IS '마지막수정자';


--
-- Name: COLUMN aas_codeinfo.last_mod_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aas_codeinfo.last_mod_date IS '마지막수정일';


--
-- Name: aasinstance; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.aasinstance (
    instance_seq bigint NOT NULL,
    instance_name character varying NOT NULL,
    description text,
    verification character varying(20),
    user_seq integer NOT NULL,
    create_user_seq integer DEFAULT 0 NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_mod_user_seq integer,
    last_mod_date timestamp with time zone
);


ALTER TABLE aasrepo.aasinstance OWNER TO postgres;

--
-- Name: TABLE aasinstance; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.aasinstance IS 'AAS인스턴스';


--
-- Name: COLUMN aasinstance.instance_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance.instance_seq IS 'AAS인스턴스SEQ';


--
-- Name: COLUMN aasinstance.instance_name; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance.instance_name IS 'AAS인스턴스명';


--
-- Name: COLUMN aasinstance.description; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance.description IS '비고';


--
-- Name: COLUMN aasinstance.verification; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance.verification IS 'AAS인스턴스검증상태,success/fail';


--
-- Name: COLUMN aasinstance.user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance.user_seq IS '인스턴스사용자';


--
-- Name: COLUMN aasinstance.create_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance.create_user_seq IS '최초생성자';


--
-- Name: COLUMN aasinstance.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance.create_date IS '최초등록일시';


--
-- Name: COLUMN aasinstance.last_mod_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance.last_mod_user_seq IS '마지막수정자';


--
-- Name: COLUMN aasinstance.last_mod_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance.last_mod_date IS '마지막수정일시';


--
-- Name: aasinstance_aasmodel_submodels; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.aasinstance_aasmodel_submodels (
    instance_seq bigint NOT NULL,
    aasmodel_seq bigint NOT NULL,
    submodel_seq bigint NOT NULL,
    metadata jsonb,
    create_user_seq integer DEFAULT 0 NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_mod_user_seq integer,
    last_mod_date timestamp with time zone
);


ALTER TABLE aasrepo.aasinstance_aasmodel_submodels OWNER TO postgres;

--
-- Name: TABLE aasinstance_aasmodel_submodels; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.aasinstance_aasmodel_submodels IS 'AAS인스턴스-AAS모델-SUB모델';


--
-- Name: COLUMN aasinstance_aasmodel_submodels.instance_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodel_submodels.instance_seq IS 'AAS인스턴스SEQ';


--
-- Name: COLUMN aasinstance_aasmodel_submodels.aasmodel_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodel_submodels.aasmodel_seq IS 'AAS모델SEQ';


--
-- Name: COLUMN aasinstance_aasmodel_submodels.submodel_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodel_submodels.submodel_seq IS 'SUB모델SEQ';


--
-- Name: COLUMN aasinstance_aasmodel_submodels.metadata; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodel_submodels.metadata IS 'SUB모델NEW_VALUE_META';


--
-- Name: COLUMN aasinstance_aasmodel_submodels.create_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodel_submodels.create_user_seq IS '최초생성자';


--
-- Name: COLUMN aasinstance_aasmodel_submodels.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodel_submodels.create_date IS '최초등록일시';


--
-- Name: COLUMN aasinstance_aasmodel_submodels.last_mod_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodel_submodels.last_mod_user_seq IS '마지막수정자';


--
-- Name: COLUMN aasinstance_aasmodel_submodels.last_mod_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodel_submodels.last_mod_date IS '마지막수정일시';


--
-- Name: aasinstance_aasmodels; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.aasinstance_aasmodels (
    instance_seq bigint NOT NULL,
    aasmodel_seq bigint NOT NULL,
    metadata jsonb,
    create_user_seq integer DEFAULT 0 NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_mod_user_seq integer,
    last_mod_date timestamp with time zone
);


ALTER TABLE aasrepo.aasinstance_aasmodels OWNER TO postgres;

--
-- Name: TABLE aasinstance_aasmodels; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.aasinstance_aasmodels IS 'AAS인스턴스-AAS모델';


--
-- Name: COLUMN aasinstance_aasmodels.instance_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodels.instance_seq IS 'AAS인스턴스SEQ';


--
-- Name: COLUMN aasinstance_aasmodels.aasmodel_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodels.aasmodel_seq IS 'AAS모델SEQ';


--
-- Name: COLUMN aasinstance_aasmodels.metadata; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodels.metadata IS 'AAS모델NEW_Value_META';


--
-- Name: COLUMN aasinstance_aasmodels.create_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodels.create_user_seq IS '최초생성자';


--
-- Name: COLUMN aasinstance_aasmodels.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodels.create_date IS '최초등록일시';


--
-- Name: COLUMN aasinstance_aasmodels.last_mod_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodels.last_mod_user_seq IS '마지막수정자';


--
-- Name: COLUMN aasinstance_aasmodels.last_mod_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasinstance_aasmodels.last_mod_date IS '마지막수정일시';


--
-- Name: aasinstance_instance_seq_seq; Type: SEQUENCE; Schema: aasrepo; Owner: postgres
--

CREATE SEQUENCE aasrepo.aasinstance_instance_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE aasrepo.aasinstance_instance_seq_seq OWNER TO postgres;

--
-- Name: aasinstance_instance_seq_seq; Type: SEQUENCE OWNED BY; Schema: aasrepo; Owner: postgres
--

ALTER SEQUENCE aasrepo.aasinstance_instance_seq_seq OWNED BY aasrepo.aasinstance.instance_seq;


--
-- Name: aaslogs_2025; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.aaslogs_2025 (
    dt timestamp without time zone,
    log_type character varying(50),
    msg text,
    target character varying(50),
    state character varying(50),
    flag character(1),
    user_seq integer
);


ALTER TABLE aasrepo.aaslogs_2025 OWNER TO postgres;

--
-- Name: TABLE aaslogs_2025; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.aaslogs_2025 IS 'AASLOGS_년도';


--
-- Name: COLUMN aaslogs_2025.dt; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aaslogs_2025.dt IS '시간';


--
-- Name: COLUMN aaslogs_2025.log_type; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aaslogs_2025.log_type IS '로그타입';


--
-- Name: COLUMN aaslogs_2025.msg; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aaslogs_2025.msg IS '로그메시지';


--
-- Name: COLUMN aaslogs_2025.target; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aaslogs_2025.target IS '프로세스ID';


--
-- Name: COLUMN aaslogs_2025.state; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aaslogs_2025.state IS '상태';


--
-- Name: COLUMN aaslogs_2025.flag; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aaslogs_2025.flag IS 'FLAG';


--
-- Name: aasmodel_attachments; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.aasmodel_attachments (
    attachment_seq bigint NOT NULL,
    aasmodel_seq bigint NOT NULL,
    filename character varying NOT NULL,
    realpath character varying NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE aasrepo.aasmodel_attachments OWNER TO postgres;

--
-- Name: TABLE aasmodel_attachments; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.aasmodel_attachments IS 'AAS모델-첨부파일';


--
-- Name: COLUMN aasmodel_attachments.attachment_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodel_attachments.attachment_seq IS '첨부파일SEQ';


--
-- Name: COLUMN aasmodel_attachments.aasmodel_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodel_attachments.aasmodel_seq IS 'AAS모델SEQ';


--
-- Name: COLUMN aasmodel_attachments.filename; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodel_attachments.filename IS '파일명';


--
-- Name: COLUMN aasmodel_attachments.realpath; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodel_attachments.realpath IS '파일서버경로';


--
-- Name: COLUMN aasmodel_attachments.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodel_attachments.create_date IS '생성일';


--
-- Name: aasmodel_attachments_attachment_seq_seq; Type: SEQUENCE; Schema: aasrepo; Owner: postgres
--

CREATE SEQUENCE aasrepo.aasmodel_attachments_attachment_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE aasrepo.aasmodel_attachments_attachment_seq_seq OWNER TO postgres;

--
-- Name: aasmodel_attachments_attachment_seq_seq; Type: SEQUENCE OWNED BY; Schema: aasrepo; Owner: postgres
--

ALTER SEQUENCE aasrepo.aasmodel_attachments_attachment_seq_seq OWNED BY aasrepo.aasmodel_attachments.attachment_seq;


--
-- Name: aasmodel_image; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.aasmodel_image (
    aasmodel_seq bigint NOT NULL,
    aasmodel_img text,
    filename character varying,
    mime_type character varying
);


ALTER TABLE aasrepo.aasmodel_image OWNER TO postgres;

--
-- Name: TABLE aasmodel_image; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.aasmodel_image IS 'AAS모델-이미지';


--
-- Name: COLUMN aasmodel_image.aasmodel_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodel_image.aasmodel_seq IS 'AAS모델SEQ';


--
-- Name: COLUMN aasmodel_image.aasmodel_img; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodel_image.aasmodel_img IS 'AAS모델_IMAGE';


--
-- Name: COLUMN aasmodel_image.filename; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodel_image.filename IS 'AAS모델_MIMETYPE';


--
-- Name: COLUMN aasmodel_image.mime_type; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodel_image.mime_type IS 'AAS모델_MIMETYPE';


--
-- Name: aasmodels; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.aasmodels (
    aasmodel_seq bigint NOT NULL,
    aasmodel_name character varying NOT NULL,
    aasmodel_id character varying NOT NULL,
    aasmodel_template_id character varying,
    version character varying(50),
    type character varying(50),
    category_seq integer,
    description text,
    status character varying(20) DEFAULT 'temporary'::character varying NOT NULL,
    source_project character varying(100),
    metadata jsonb,
    create_user_seq integer DEFAULT 0 NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_mod_user_seq integer,
    last_mod_date timestamp with time zone
);


ALTER TABLE aasrepo.aasmodels OWNER TO postgres;

--
-- Name: TABLE aasmodels; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.aasmodels IS 'AAS모델';


--
-- Name: COLUMN aasmodels.aasmodel_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.aasmodel_seq IS 'AAS모델SEQ';


--
-- Name: COLUMN aasmodels.aasmodel_name; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.aasmodel_name IS 'AAS모델명';


--
-- Name: COLUMN aasmodels.aasmodel_id; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.aasmodel_id IS 'AAS모델ID';


--
-- Name: COLUMN aasmodels.aasmodel_template_id; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.aasmodel_template_id IS 'AAS모델템플릿ID';


--
-- Name: COLUMN aasmodels.version; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.version IS 'AAS모델버전';


--
-- Name: COLUMN aasmodels.type; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.type IS 'AAS모델타입 template/instance';


--
-- Name: COLUMN aasmodels.category_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.category_seq IS '산업분류카테고리 FK';


--
-- Name: COLUMN aasmodels.description; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.description IS '비고';


--
-- Name: COLUMN aasmodels.status; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.status IS 'temporary/draft/published/deprecated';


--
-- Name: COLUMN aasmodels.source_project; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.source_project IS 'e.g., "중기부참조모델", "자율제조"';


--
-- Name: COLUMN aasmodels.metadata; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.metadata IS 'Flexible metadata storage';


--
-- Name: COLUMN aasmodels.create_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.create_user_seq IS '최초생성자';


--
-- Name: COLUMN aasmodels.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.create_date IS '최초등록일시';


--
-- Name: COLUMN aasmodels.last_mod_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.aasmodels.last_mod_user_seq IS '마지막수정자';


--
-- Name: aasmodels_aasmodel_seq_seq; Type: SEQUENCE; Schema: aasrepo; Owner: postgres
--

CREATE SEQUENCE aasrepo.aasmodels_aasmodel_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE aasrepo.aasmodels_aasmodel_seq_seq OWNER TO postgres;

--
-- Name: aasmodels_aasmodel_seq_seq; Type: SEQUENCE OWNED BY; Schema: aasrepo; Owner: postgres
--

ALTER SEQUENCE aasrepo.aasmodels_aasmodel_seq_seq OWNED BY aasrepo.aasmodels.aasmodel_seq;


--
-- Name: categories; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.categories (
    category_seq integer NOT NULL,
    category_name character varying NOT NULL,
    category_name2 character varying,
    category_name3 character varying,
    category_name4 character varying,
    category_name5 character varying,
    description text,
    status character(1) DEFAULT 'Y'::bpchar NOT NULL,
    refcode1 character varying,
    refcode2 character varying,
    refcode3 character varying,
    create_user_seq integer DEFAULT 0 NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_mod_user_seq integer,
    last_mod_date timestamp with time zone
);


ALTER TABLE aasrepo.categories OWNER TO postgres;

--
-- Name: TABLE categories; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.categories IS '모델카테고리(산업분류)';


--
-- Name: COLUMN categories.category_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.category_seq IS '모델카테고리시퀀스';


--
-- Name: COLUMN categories.category_name; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.category_name IS '모델카테고리명(영어)';


--
-- Name: COLUMN categories.category_name2; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.category_name2 IS '모델카테고리명(한국)';


--
-- Name: COLUMN categories.category_name3; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.category_name3 IS '모델카테고리명()';


--
-- Name: COLUMN categories.category_name4; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.category_name4 IS '모델카테고리명()';


--
-- Name: COLUMN categories.category_name5; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.category_name5 IS '모델카테고리명()';


--
-- Name: COLUMN categories.description; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.description IS '비고';


--
-- Name: COLUMN categories.status; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.status IS 'Y=활성,N=비활성';


--
-- Name: COLUMN categories.refcode1; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.refcode1 IS '카테고리-대분류';


--
-- Name: COLUMN categories.refcode2; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.refcode2 IS '카테고리-중분류';


--
-- Name: COLUMN categories.refcode3; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.refcode3 IS '카테고리-소분류';


--
-- Name: COLUMN categories.create_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.create_user_seq IS '최초생성자';


--
-- Name: COLUMN categories.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.create_date IS '최초등록일시';


--
-- Name: COLUMN categories.last_mod_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.last_mod_user_seq IS '마지막수정자';


--
-- Name: COLUMN categories.last_mod_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.categories.last_mod_date IS '마지막수정일시';


--
-- Name: categories_category_seq_seq; Type: SEQUENCE; Schema: aasrepo; Owner: postgres
--

CREATE SEQUENCE aasrepo.categories_category_seq_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE aasrepo.categories_category_seq_seq OWNER TO postgres;

--
-- Name: categories_category_seq_seq; Type: SEQUENCE OWNED BY; Schema: aasrepo; Owner: postgres
--

ALTER SEQUENCE aasrepo.categories_category_seq_seq OWNED BY aasrepo.categories.category_seq;


--
-- Name: groups; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.groups (
    group_seq integer NOT NULL,
    group_name character varying NOT NULL,
    group_name2 character varying,
    group_name3 character varying,
    group_name4 character varying,
    group_name5 character varying,
    description text,
    status character(1) DEFAULT 'Y'::bpchar NOT NULL,
    create_user_seq integer DEFAULT 0 NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_mod_user_seq integer,
    last_mod_date timestamp with time zone
);


ALTER TABLE aasrepo.groups OWNER TO postgres;

--
-- Name: TABLE groups; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.groups IS '그룹';


--
-- Name: COLUMN groups.group_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.groups.group_seq IS '그룹시퀀스';


--
-- Name: COLUMN groups.group_name; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.groups.group_name IS '그룹명(영어)';


--
-- Name: COLUMN groups.group_name2; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.groups.group_name2 IS '그룹명(한국)';


--
-- Name: COLUMN groups.group_name3; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.groups.group_name3 IS '그룹명()';


--
-- Name: COLUMN groups.group_name4; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.groups.group_name4 IS '그룹명()';


--
-- Name: COLUMN groups.group_name5; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.groups.group_name5 IS '그룹명()';


--
-- Name: COLUMN groups.description; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.groups.description IS '비고';


--
-- Name: COLUMN groups.status; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.groups.status IS 'Y=활성,N=비활성';


--
-- Name: COLUMN groups.create_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.groups.create_user_seq IS '최초생성자';


--
-- Name: COLUMN groups.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.groups.create_date IS '최초등록일시';


--
-- Name: COLUMN groups.last_mod_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.groups.last_mod_user_seq IS '마지막수정자';


--
-- Name: COLUMN groups.last_mod_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.groups.last_mod_date IS '마지막수정일시';


--
-- Name: groups_group_seq_seq; Type: SEQUENCE; Schema: aasrepo; Owner: postgres
--

CREATE SEQUENCE aasrepo.groups_group_seq_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE aasrepo.groups_group_seq_seq OWNER TO postgres;

--
-- Name: groups_group_seq_seq; Type: SEQUENCE OWNED BY; Schema: aasrepo; Owner: postgres
--

ALTER SEQUENCE aasrepo.groups_group_seq_seq OWNED BY aasrepo.groups.group_seq;


--
-- Name: socialaccounts; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.socialaccounts (
    socialaccount_seq integer NOT NULL,
    socialprovider_seq integer NOT NULL,
    social_id character varying NOT NULL,
    social_in_id character varying NOT NULL,
    user_seq integer NOT NULL,
    access_token character varying NOT NULL,
    refresh_token character varying NOT NULL,
    description text,
    status character(1) NOT NULL,
    create_user_seq integer DEFAULT 0 NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_mod_user_seq integer,
    last_mod_date timestamp with time zone
);


ALTER TABLE aasrepo.socialaccounts OWNER TO postgres;

--
-- Name: TABLE socialaccounts; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.socialaccounts IS '소셜어카운트';


--
-- Name: COLUMN socialaccounts.socialaccount_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialaccounts.socialaccount_seq IS '소셜어카운트시퀀스';


--
-- Name: COLUMN socialaccounts.social_id; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialaccounts.social_id IS '소셜아이디(이메일)';


--
-- Name: COLUMN socialaccounts.social_in_id; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialaccounts.social_in_id IS '소셜아이디(내부ID)';


--
-- Name: COLUMN socialaccounts.user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialaccounts.user_seq IS '사용자시퀀스(참조키)';


--
-- Name: COLUMN socialaccounts.access_token; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialaccounts.access_token IS '소셜엑세스토큰';


--
-- Name: COLUMN socialaccounts.refresh_token; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialaccounts.refresh_token IS '소셜갱신토큰';


--
-- Name: COLUMN socialaccounts.description; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialaccounts.description IS '비고';


--
-- Name: COLUMN socialaccounts.status; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialaccounts.status IS 'Y=활성,N=비활성';


--
-- Name: COLUMN socialaccounts.create_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialaccounts.create_user_seq IS '최초생성자';


--
-- Name: COLUMN socialaccounts.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialaccounts.create_date IS '최초등록일시';


--
-- Name: COLUMN socialaccounts.last_mod_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialaccounts.last_mod_user_seq IS '마지막수정자';


--
-- Name: COLUMN socialaccounts.last_mod_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialaccounts.last_mod_date IS '마지막수정일시';


--
-- Name: socialaccounts_socialaccount_seq_seq; Type: SEQUENCE; Schema: aasrepo; Owner: postgres
--

CREATE SEQUENCE aasrepo.socialaccounts_socialaccount_seq_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE aasrepo.socialaccounts_socialaccount_seq_seq OWNER TO postgres;

--
-- Name: socialaccounts_socialaccount_seq_seq; Type: SEQUENCE OWNED BY; Schema: aasrepo; Owner: postgres
--

ALTER SEQUENCE aasrepo.socialaccounts_socialaccount_seq_seq OWNED BY aasrepo.socialaccounts.socialaccount_seq;


--
-- Name: socialproviders; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.socialproviders (
    socialprovider_seq bigint NOT NULL,
    socialprovider_name character varying NOT NULL,
    description text,
    status character(1) DEFAULT 'Y'::bpchar NOT NULL,
    create_user_seq integer DEFAULT 0 NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_mod_user_seq integer,
    last_mod_date timestamp with time zone
);


ALTER TABLE aasrepo.socialproviders OWNER TO postgres;

--
-- Name: TABLE socialproviders; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.socialproviders IS '소셜프로바이더(소셜로그인)';


--
-- Name: COLUMN socialproviders.socialprovider_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialproviders.socialprovider_seq IS '소셜시퀀스';


--
-- Name: COLUMN socialproviders.socialprovider_name; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialproviders.socialprovider_name IS '소셜프로바이더명';


--
-- Name: COLUMN socialproviders.description; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialproviders.description IS '비고';


--
-- Name: COLUMN socialproviders.status; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialproviders.status IS 'Y=활성,N=비활성';


--
-- Name: COLUMN socialproviders.create_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialproviders.create_user_seq IS '최초생성자';


--
-- Name: COLUMN socialproviders.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialproviders.create_date IS '최초등록일시';


--
-- Name: COLUMN socialproviders.last_mod_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialproviders.last_mod_user_seq IS '마지막수정자';


--
-- Name: COLUMN socialproviders.last_mod_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.socialproviders.last_mod_date IS '마지막수정일시';


--
-- Name: socialproviders_socialprovider_seq_seq; Type: SEQUENCE; Schema: aasrepo; Owner: postgres
--

CREATE SEQUENCE aasrepo.socialproviders_socialprovider_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE aasrepo.socialproviders_socialprovider_seq_seq OWNER TO postgres;

--
-- Name: socialproviders_socialprovider_seq_seq; Type: SEQUENCE OWNED BY; Schema: aasrepo; Owner: postgres
--

ALTER SEQUENCE aasrepo.socialproviders_socialprovider_seq_seq OWNED BY aasrepo.socialproviders.socialprovider_seq;


--
-- Name: submodel_image; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.submodel_image (
    submodel_seq bigint NOT NULL,
    submodel_img text,
    filename character varying,
    mime_type character varying
);


ALTER TABLE aasrepo.submodel_image OWNER TO postgres;

--
-- Name: TABLE submodel_image; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.submodel_image IS 'AAS모델-이미지';


--
-- Name: COLUMN submodel_image.submodel_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodel_image.submodel_seq IS 'AAS서브모델SEQ';


--
-- Name: COLUMN submodel_image.submodel_img; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodel_image.submodel_img IS 'AAS서브모델_IMAGE';


--
-- Name: COLUMN submodel_image.filename; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodel_image.filename IS 'AAS모델_MIMETYPE';


--
-- Name: COLUMN submodel_image.mime_type; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodel_image.mime_type IS 'AAS모델_MIMETYPE';


--
-- Name: submodels; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.submodels (
    submodel_seq bigint NOT NULL,
    submodel_name character varying NOT NULL,
    submodel_id character varying,
    submodel_semantic_id character varying,
    submodel_template_id character varying,
    submodel_version character varying(50),
    submodel_type character varying(50),
    category_seq integer,
    description text,
    status character varying(20) DEFAULT 'temporary'::character varying NOT NULL,
    metadata jsonb,
    create_user_seq integer DEFAULT 0 NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_mod_user_seq integer,
    last_mod_date timestamp with time zone
);


ALTER TABLE aasrepo.submodels OWNER TO postgres;

--
-- Name: TABLE submodels; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.submodels IS 'SUB모델';


--
-- Name: COLUMN submodels.submodel_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.submodel_seq IS 'SUB모델SEQ';


--
-- Name: COLUMN submodels.submodel_name; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.submodel_name IS 'SUB모델명';


--
-- Name: COLUMN submodels.submodel_id; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.submodel_id IS 'SUB모델ID';


--
-- Name: COLUMN submodels.submodel_semantic_id; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.submodel_semantic_id IS 'SUB모델 SEMANTIC_ID';


--
-- Name: COLUMN submodels.submodel_template_id; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.submodel_template_id IS 'SUB모델 TEMPLATE_ID';


--
-- Name: COLUMN submodels.submodel_version; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.submodel_version IS 'SUB모델버전';


--
-- Name: COLUMN submodels.submodel_type; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.submodel_type IS 'SUB모델타입 json/xml/aml';


--
-- Name: COLUMN submodels.category_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.category_seq IS '산업분류카테고리 FK';


--
-- Name: COLUMN submodels.description; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.description IS '비고';


--
-- Name: COLUMN submodels.status; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.status IS 'temporary/draft/published/deprecated';


--
-- Name: COLUMN submodels.metadata; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.metadata IS 'Flexible metadata storage';


--
-- Name: COLUMN submodels.create_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.create_user_seq IS '최초생성자';


--
-- Name: COLUMN submodels.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.create_date IS '최초등록일시';


--
-- Name: COLUMN submodels.last_mod_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.last_mod_user_seq IS '마지막수정자';


--
-- Name: COLUMN submodels.last_mod_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.submodels.last_mod_date IS '마지막수정일';


--
-- Name: submodels_submodel_seq_seq; Type: SEQUENCE; Schema: aasrepo; Owner: postgres
--

CREATE SEQUENCE aasrepo.submodels_submodel_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE aasrepo.submodels_submodel_seq_seq OWNER TO postgres;

--
-- Name: submodels_submodel_seq_seq; Type: SEQUENCE OWNED BY; Schema: aasrepo; Owner: postgres
--

ALTER SEQUENCE aasrepo.submodels_submodel_seq_seq OWNED BY aasrepo.submodels.submodel_seq;


--
-- Name: users; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.users (
    user_seq bigint NOT NULL,
    user_id character varying NOT NULL,
    pw_hash character varying,
    user_name character varying NOT NULL,
    user_phonenumber character varying,
    status character(1) DEFAULT 'Y'::bpchar NOT NULL,
    start_timestamp timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    close_timestamp timestamp with time zone,
    create_user_seq integer DEFAULT 0 NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    last_mod_user_seq integer,
    last_mod_date timestamp with time zone
);


ALTER TABLE aasrepo.users OWNER TO postgres;

--
-- Name: TABLE users; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.users IS '사용자,로그인';


--
-- Name: COLUMN users.user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users.user_seq IS '사용자시퀀스';


--
-- Name: COLUMN users.user_id; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users.user_id IS '사용자아이디';


--
-- Name: COLUMN users.pw_hash; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users.pw_hash IS '해쉬암호';


--
-- Name: COLUMN users.user_name; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users.user_name IS '사용자명';


--
-- Name: COLUMN users.user_phonenumber; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users.user_phonenumber IS '사용자폰번호';


--
-- Name: COLUMN users.status; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users.status IS 'Y=활성,N=비활성';


--
-- Name: COLUMN users.start_timestamp; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users.start_timestamp IS '가입일시';


--
-- Name: COLUMN users.close_timestamp; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users.close_timestamp IS '탈퇴일시';


--
-- Name: COLUMN users.create_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users.create_user_seq IS '최초생성자';


--
-- Name: COLUMN users.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users.create_date IS '최초등록일시';


--
-- Name: COLUMN users.last_mod_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users.last_mod_user_seq IS '마지막수정자';


--
-- Name: COLUMN users.last_mod_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users.last_mod_date IS '마지막수정일시';


--
-- Name: users_group; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.users_group (
    user_seq integer NOT NULL,
    group_seq integer NOT NULL
);


ALTER TABLE aasrepo.users_group OWNER TO postgres;

--
-- Name: TABLE users_group; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.users_group IS '사용자-그룹';


--
-- Name: COLUMN users_group.user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users_group.user_seq IS '사용자';


--
-- Name: COLUMN users_group.group_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.users_group.group_seq IS '그룹';


--
-- Name: users_user_seq_seq; Type: SEQUENCE; Schema: aasrepo; Owner: postgres
--

CREATE SEQUENCE aasrepo.users_user_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE aasrepo.users_user_seq_seq OWNER TO postgres;

--
-- Name: users_user_seq_seq; Type: SEQUENCE OWNED BY; Schema: aasrepo; Owner: postgres
--

ALTER SEQUENCE aasrepo.users_user_seq_seq OWNED BY aasrepo.users.user_seq;


--
-- Name: validations; Type: TABLE; Schema: aasrepo; Owner: postgres
--

CREATE TABLE aasrepo.validations (
    validation_seq bigint NOT NULL,
    target_type character varying(50) NOT NULL,
    target_seq integer,
    target_id character varying NOT NULL,
    validation_result jsonb,
    description text,
    status character varying NOT NULL,
    create_user_seq integer DEFAULT 0 NOT NULL,
    create_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE aasrepo.validations OWNER TO postgres;

--
-- Name: TABLE validations; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON TABLE aasrepo.validations IS '검증결과';


--
-- Name: COLUMN validations.validation_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.validations.validation_seq IS '검증시퀀스';


--
-- Name: COLUMN validations.target_type; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.validations.target_type IS '타겟타입(AAS,서브모델,인스턴스)';


--
-- Name: COLUMN validations.target_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.validations.target_seq IS '타겟시퀀스(참조)';


--
-- Name: COLUMN validations.target_id; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.validations.target_id IS '타겟ID(참조)';


--
-- Name: COLUMN validations.validation_result; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.validations.validation_result IS '비고(결과내용)';


--
-- Name: COLUMN validations.description; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.validations.description IS '비고';


--
-- Name: COLUMN validations.status; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.validations.status IS 'sucess=활성,fail=비활성';


--
-- Name: COLUMN validations.create_user_seq; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.validations.create_user_seq IS '최초생성자';


--
-- Name: COLUMN validations.create_date; Type: COMMENT; Schema: aasrepo; Owner: postgres
--

COMMENT ON COLUMN aasrepo.validations.create_date IS '최초등록일시';


--
-- Name: validations_validation_seq_seq; Type: SEQUENCE; Schema: aasrepo; Owner: postgres
--

CREATE SEQUENCE aasrepo.validations_validation_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE aasrepo.validations_validation_seq_seq OWNER TO postgres;

--
-- Name: validations_validation_seq_seq; Type: SEQUENCE OWNED BY; Schema: aasrepo; Owner: postgres
--

ALTER SEQUENCE aasrepo.validations_validation_seq_seq OWNED BY aasrepo.validations.validation_seq;


--
-- Name: aasinstance instance_seq; Type: DEFAULT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasinstance ALTER COLUMN instance_seq SET DEFAULT nextval('aasrepo.aasinstance_instance_seq_seq'::regclass);


--
-- Name: aasmodel_attachments attachment_seq; Type: DEFAULT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasmodel_attachments ALTER COLUMN attachment_seq SET DEFAULT nextval('aasrepo.aasmodel_attachments_attachment_seq_seq'::regclass);


--
-- Name: aasmodels aasmodel_seq; Type: DEFAULT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasmodels ALTER COLUMN aasmodel_seq SET DEFAULT nextval('aasrepo.aasmodels_aasmodel_seq_seq'::regclass);


--
-- Name: categories category_seq; Type: DEFAULT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.categories ALTER COLUMN category_seq SET DEFAULT nextval('aasrepo.categories_category_seq_seq'::regclass);


--
-- Name: groups group_seq; Type: DEFAULT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.groups ALTER COLUMN group_seq SET DEFAULT nextval('aasrepo.groups_group_seq_seq'::regclass);


--
-- Name: socialaccounts socialaccount_seq; Type: DEFAULT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.socialaccounts ALTER COLUMN socialaccount_seq SET DEFAULT nextval('aasrepo.socialaccounts_socialaccount_seq_seq'::regclass);


--
-- Name: socialproviders socialprovider_seq; Type: DEFAULT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.socialproviders ALTER COLUMN socialprovider_seq SET DEFAULT nextval('aasrepo.socialproviders_socialprovider_seq_seq'::regclass);


--
-- Name: submodels submodel_seq; Type: DEFAULT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.submodels ALTER COLUMN submodel_seq SET DEFAULT nextval('aasrepo.submodels_submodel_seq_seq'::regclass);


--
-- Name: users user_seq; Type: DEFAULT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.users ALTER COLUMN user_seq SET DEFAULT nextval('aasrepo.users_user_seq_seq'::regclass);


--
-- Name: validations validation_seq; Type: DEFAULT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.validations ALTER COLUMN validation_seq SET DEFAULT nextval('aasrepo.validations_validation_seq_seq'::regclass);


--
-- Data for Name: aas_codeinfo; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.aas_codeinfo (grpcode, code, codename, codename2, codename3, codename4, codename5, refcode1, refcode2, refcode3, refcode4, refcode5, sortkey, description, status, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM stdin;
\.
COPY aasrepo.aas_codeinfo (grpcode, code, codename, codename2, codename3, codename4, codename5, refcode1, refcode2, refcode3, refcode4, refcode5, sortkey, description, status, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM '$$PATH$$/4023.dat';

--
-- Data for Name: aasinstance; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.aasinstance (instance_seq, instance_name, description, verification, user_seq, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM stdin;
\.
COPY aasrepo.aasinstance (instance_seq, instance_name, description, verification, user_seq, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM '$$PATH$$/4044.dat';

--
-- Data for Name: aasinstance_aasmodel_submodels; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.aasinstance_aasmodel_submodels (instance_seq, aasmodel_seq, submodel_seq, metadata, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM stdin;
\.
COPY aasrepo.aasinstance_aasmodel_submodels (instance_seq, aasmodel_seq, submodel_seq, metadata, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM '$$PATH$$/4036.dat';

--
-- Data for Name: aasinstance_aasmodels; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.aasinstance_aasmodels (instance_seq, aasmodel_seq, metadata, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM stdin;
\.
COPY aasrepo.aasinstance_aasmodels (instance_seq, aasmodel_seq, metadata, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM '$$PATH$$/4035.dat';

--
-- Data for Name: aaslogs_2025; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.aaslogs_2025 (dt, log_type, msg, target, state, flag, user_seq) FROM stdin;
\.
COPY aasrepo.aaslogs_2025 (dt, log_type, msg, target, state, flag, user_seq) FROM '$$PATH$$/4045.dat';

--
-- Data for Name: aasmodel_attachments; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.aasmodel_attachments (attachment_seq, aasmodel_seq, filename, realpath, create_date) FROM stdin;
\.
COPY aasrepo.aasmodel_attachments (attachment_seq, aasmodel_seq, filename, realpath, create_date) FROM '$$PATH$$/4038.dat';

--
-- Data for Name: aasmodel_image; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.aasmodel_image (aasmodel_seq, aasmodel_img, filename, mime_type) FROM stdin;
\.
COPY aasrepo.aasmodel_image (aasmodel_seq, aasmodel_img, filename, mime_type) FROM '$$PATH$$/4041.dat';

--
-- Data for Name: aasmodels; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.aasmodels (aasmodel_seq, aasmodel_name, aasmodel_id, aasmodel_template_id, version, type, category_seq, description, status, source_project, metadata, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM stdin;
\.
COPY aasrepo.aasmodels (aasmodel_seq, aasmodel_name, aasmodel_id, aasmodel_template_id, version, type, category_seq, description, status, source_project, metadata, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM '$$PATH$$/4040.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.categories (category_seq, category_name, category_name2, category_name3, category_name4, category_name5, description, status, refcode1, refcode2, refcode3, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM stdin;
\.
COPY aasrepo.categories (category_seq, category_name, category_name2, category_name3, category_name4, category_name5, description, status, refcode1, refcode2, refcode3, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM '$$PATH$$/4034.dat';

--
-- Data for Name: groups; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.groups (group_seq, group_name, group_name2, group_name3, group_name4, group_name5, description, status, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM stdin;
\.
COPY aasrepo.groups (group_seq, group_name, group_name2, group_name3, group_name4, group_name5, description, status, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM '$$PATH$$/4024.dat';

--
-- Data for Name: socialaccounts; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.socialaccounts (socialaccount_seq, socialprovider_seq, social_id, social_in_id, user_seq, access_token, refresh_token, description, status, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM stdin;
\.
COPY aasrepo.socialaccounts (socialaccount_seq, socialprovider_seq, social_id, social_in_id, user_seq, access_token, refresh_token, description, status, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM '$$PATH$$/4026.dat';

--
-- Data for Name: socialproviders; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.socialproviders (socialprovider_seq, socialprovider_name, description, status, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM stdin;
\.
COPY aasrepo.socialproviders (socialprovider_seq, socialprovider_name, description, status, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM '$$PATH$$/4028.dat';

--
-- Data for Name: submodel_image; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.submodel_image (submodel_seq, submodel_img, filename, mime_type) FROM stdin;
\.
COPY aasrepo.submodel_image (submodel_seq, submodel_img, filename, mime_type) FROM '$$PATH$$/4042.dat';

--
-- Data for Name: submodels; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.submodels (submodel_seq, submodel_name, submodel_id, submodel_semantic_id, submodel_template_id, submodel_version, submodel_type, category_seq, description, status, metadata, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM stdin;
\.
COPY aasrepo.submodels (submodel_seq, submodel_name, submodel_id, submodel_semantic_id, submodel_template_id, submodel_version, submodel_type, category_seq, description, status, metadata, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM '$$PATH$$/4049.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.users (user_seq, user_id, pw_hash, user_name, user_phonenumber, status, start_timestamp, close_timestamp, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM stdin;
\.
COPY aasrepo.users (user_seq, user_id, pw_hash, user_name, user_phonenumber, status, start_timestamp, close_timestamp, create_user_seq, create_date, last_mod_user_seq, last_mod_date) FROM '$$PATH$$/4032.dat';

--
-- Data for Name: users_group; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.users_group (user_seq, group_seq) FROM stdin;
\.
COPY aasrepo.users_group (user_seq, group_seq) FROM '$$PATH$$/4030.dat';

--
-- Data for Name: validations; Type: TABLE DATA; Schema: aasrepo; Owner: postgres
--

COPY aasrepo.validations (validation_seq, target_type, target_seq, target_id, validation_result, description, status, create_user_seq, create_date) FROM stdin;
\.
COPY aasrepo.validations (validation_seq, target_type, target_seq, target_id, validation_result, description, status, create_user_seq, create_date) FROM '$$PATH$$/4047.dat';

--
-- Name: aasinstance_instance_seq_seq; Type: SEQUENCE SET; Schema: aasrepo; Owner: postgres
--

SELECT pg_catalog.setval('aasrepo.aasinstance_instance_seq_seq', 3, true);


--
-- Name: aasmodel_attachments_attachment_seq_seq; Type: SEQUENCE SET; Schema: aasrepo; Owner: postgres
--

SELECT pg_catalog.setval('aasrepo.aasmodel_attachments_attachment_seq_seq', 1, false);


--
-- Name: aasmodels_aasmodel_seq_seq; Type: SEQUENCE SET; Schema: aasrepo; Owner: postgres
--

SELECT pg_catalog.setval('aasrepo.aasmodels_aasmodel_seq_seq', 2, true);


--
-- Name: categories_category_seq_seq; Type: SEQUENCE SET; Schema: aasrepo; Owner: postgres
--

SELECT pg_catalog.setval('aasrepo.categories_category_seq_seq', 12, true);


--
-- Name: groups_group_seq_seq; Type: SEQUENCE SET; Schema: aasrepo; Owner: postgres
--

SELECT pg_catalog.setval('aasrepo.groups_group_seq_seq', 3, true);


--
-- Name: socialaccounts_socialaccount_seq_seq; Type: SEQUENCE SET; Schema: aasrepo; Owner: postgres
--

SELECT pg_catalog.setval('aasrepo.socialaccounts_socialaccount_seq_seq', 10, true);


--
-- Name: socialproviders_socialprovider_seq_seq; Type: SEQUENCE SET; Schema: aasrepo; Owner: postgres
--

SELECT pg_catalog.setval('aasrepo.socialproviders_socialprovider_seq_seq', 1, false);


--
-- Name: submodels_submodel_seq_seq; Type: SEQUENCE SET; Schema: aasrepo; Owner: postgres
--

SELECT pg_catalog.setval('aasrepo.submodels_submodel_seq_seq', 6, true);


--
-- Name: users_user_seq_seq; Type: SEQUENCE SET; Schema: aasrepo; Owner: postgres
--

SELECT pg_catalog.setval('aasrepo.users_user_seq_seq', 6, true);


--
-- Name: validations_validation_seq_seq; Type: SEQUENCE SET; Schema: aasrepo; Owner: postgres
--

SELECT pg_catalog.setval('aasrepo.validations_validation_seq_seq', 27, true);


--
-- Name: aasinstance aas_instance_pk; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasinstance
    ADD CONSTRAINT aas_instance_pk PRIMARY KEY (instance_seq);


--
-- Name: aasmodel_attachments aasmodel_attachments_pkey; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasmodel_attachments
    ADD CONSTRAINT aasmodel_attachments_pkey PRIMARY KEY (attachment_seq);


--
-- Name: aasmodel_image aasmodels_image_unique; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasmodel_image
    ADD CONSTRAINT aasmodels_image_unique UNIQUE (aasmodel_seq);


--
-- Name: aasmodels aasmodels_pk; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasmodels
    ADD CONSTRAINT aasmodels_pk PRIMARY KEY (aasmodel_seq);


--
-- Name: aas_codeinfo aasrepocode_pk; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aas_codeinfo
    ADD CONSTRAINT aasrepocode_pk PRIMARY KEY (code);


--
-- Name: categories categories_pk; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.categories
    ADD CONSTRAINT categories_pk PRIMARY KEY (category_seq);


--
-- Name: groups group_pk; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.groups
    ADD CONSTRAINT group_pk PRIMARY KEY (group_seq);


--
-- Name: aasinstance_aasmodel_submodels instance_aasmodel_submodels_unique; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasinstance_aasmodel_submodels
    ADD CONSTRAINT instance_aasmodel_submodels_unique UNIQUE (instance_seq, aasmodel_seq, submodel_seq);


--
-- Name: aasinstance_aasmodels instance_aasmodels_unique; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasinstance_aasmodels
    ADD CONSTRAINT instance_aasmodels_unique UNIQUE (instance_seq, aasmodel_seq);


--
-- Name: socialaccounts socialaccounts_pk; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.socialaccounts
    ADD CONSTRAINT socialaccounts_pk PRIMARY KEY (socialaccount_seq);


--
-- Name: socialproviders socialproviders_pk; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.socialproviders
    ADD CONSTRAINT socialproviders_pk PRIMARY KEY (socialprovider_seq);


--
-- Name: submodel_image submodel_image_unique; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.submodel_image
    ADD CONSTRAINT submodel_image_unique UNIQUE (submodel_seq);


--
-- Name: submodels submodels_pk; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.submodels
    ADD CONSTRAINT submodels_pk PRIMARY KEY (submodel_seq);


--
-- Name: aasmodel_attachments unique_aasmodel_seq_filename; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasmodel_attachments
    ADD CONSTRAINT unique_aasmodel_seq_filename UNIQUE (aasmodel_seq, filename);


--
-- Name: users_group users_group_unique; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.users_group
    ADD CONSTRAINT users_group_unique UNIQUE (user_seq);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.users
    ADD CONSTRAINT users_pk PRIMARY KEY (user_seq);


--
-- Name: validations validations_pk; Type: CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.validations
    ADD CONSTRAINT validations_pk PRIMARY KEY (validation_seq);


--
-- Name: aasinstance_aasmodel_submodels aasinstance_aasmodel_submodels_aasmodels_fk; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasinstance_aasmodel_submodels
    ADD CONSTRAINT aasinstance_aasmodel_submodels_aasmodels_fk FOREIGN KEY (aasmodel_seq) REFERENCES aasrepo.aasmodels(aasmodel_seq);


--
-- Name: aasinstance_aasmodels aasinstance_aasmodels_aasinstance_fk; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasinstance_aasmodels
    ADD CONSTRAINT aasinstance_aasmodels_aasinstance_fk FOREIGN KEY (instance_seq) REFERENCES aasrepo.aasinstance(instance_seq);


--
-- Name: aasinstance_aasmodels aasinstance_aasmodels_aasmodels_fk; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasinstance_aasmodels
    ADD CONSTRAINT aasinstance_aasmodels_aasmodels_fk FOREIGN KEY (aasmodel_seq) REFERENCES aasrepo.aasmodels(aasmodel_seq);


--
-- Name: aasinstance aasinstance_users_fk; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasinstance
    ADD CONSTRAINT aasinstance_users_fk FOREIGN KEY (user_seq) REFERENCES aasrepo.users(user_seq);


--
-- Name: aasmodel_attachments aasmodel_attachments_aasmodels_fk; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasmodel_attachments
    ADD CONSTRAINT aasmodel_attachments_aasmodels_fk FOREIGN KEY (aasmodel_seq) REFERENCES aasrepo.aasmodels(aasmodel_seq);


--
-- Name: aasmodel_image aasmodel_image_aasmodels_fk; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasmodel_image
    ADD CONSTRAINT aasmodel_image_aasmodels_fk FOREIGN KEY (aasmodel_seq) REFERENCES aasrepo.aasmodels(aasmodel_seq);


--
-- Name: aasmodels aasmodels_categories_fk; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.aasmodels
    ADD CONSTRAINT aasmodels_categories_fk FOREIGN KEY (category_seq) REFERENCES aasrepo.categories(category_seq);


--
-- Name: socialaccounts socialaccounts_fk1; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.socialaccounts
    ADD CONSTRAINT socialaccounts_fk1 FOREIGN KEY (socialprovider_seq) REFERENCES aasrepo.socialproviders(socialprovider_seq);


--
-- Name: socialaccounts socialaccounts_users_fk; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.socialaccounts
    ADD CONSTRAINT socialaccounts_users_fk FOREIGN KEY (user_seq) REFERENCES aasrepo.users(user_seq);


--
-- Name: submodel_image submodel_image_submodels_fk; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.submodel_image
    ADD CONSTRAINT submodel_image_submodels_fk FOREIGN KEY (submodel_seq) REFERENCES aasrepo.submodels(submodel_seq);


--
-- Name: submodels submodels_categories_fk; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.submodels
    ADD CONSTRAINT submodels_categories_fk FOREIGN KEY (category_seq) REFERENCES aasrepo.categories(category_seq);


--
-- Name: users_group users_group_groups_fk; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.users_group
    ADD CONSTRAINT users_group_groups_fk FOREIGN KEY (group_seq) REFERENCES aasrepo.groups(group_seq);


--
-- Name: users_group users_group_users_fk; Type: FK CONSTRAINT; Schema: aasrepo; Owner: postgres
--

ALTER TABLE ONLY aasrepo.users_group
    ADD CONSTRAINT users_group_users_fk FOREIGN KEY (user_seq) REFERENCES aasrepo.users(user_seq);


--
-- PostgreSQL database dump complete
--

